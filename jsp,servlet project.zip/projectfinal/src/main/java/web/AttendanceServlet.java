package web;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Attendance;
import java.io.IOException;
import java.sql.SQLException;
import dao.AttendanceDao;

@WebServlet("/attendance")
public class AttendanceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	AttendanceDao dao;

	public AttendanceServlet() throws ClassNotFoundException, SQLException {
		super();

		dao = new AttendanceDao();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.getWriter().append("Served at: ").append(request.getContextPath());

		String action = request.getParameter("action");

		if (action == null) {
			action = "default";
		}
		switch (action) {

		case "delete":

			// System.out.println(action);
			int id = Integer.parseInt(request.getParameter("id"));
			dao.delete(id);
			RequestDispatcher del = request.getRequestDispatcher("attendanceview.jsp");
			request.setAttribute("attendances", dao.getAllAttendance());
			del.forward(request, response);

			break;

		case "edit":

			RequestDispatcher edit = request.getRequestDispatcher("attendance.jsp");
			id = Integer.parseInt(request.getParameter("id"));
			Attendance attendance = dao.editAttendance(id);
			request.setAttribute("attendance", attendance);
			edit.forward(request, response);
			break;

		default:

			RequestDispatcher view = request.getRequestDispatcher("attendanceview.jsp");
			request.setAttribute("attendances", dao.getAllAttendance());
			view.forward(request, response);
			break;
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// doGet(request, response);
		Attendance attendance = new Attendance();

		attendance.setRollnum(request.getParameter("rollnum"));
		attendance.setName(request.getParameter("name"));
		attendance.setStd(request.getParameter("grade"));
		attendance.setSec(request.getParameter("section"));
		attendance.setTotaldays(request.getParameter("totaldays"));
		attendance.setLeavedays(request.getParameter("leavedays"));
		attendance.setPercentage(Double.parseDouble(request.getParameter("percentage")));

		String id = request.getParameter("id");
		try {
			if (id == null || id.isEmpty()) {
				dao.addDetails(attendance);
				request.setAttribute("status", "success");
			} else {
				attendance.setId(Integer.parseInt(id));
				dao.updateattendance(attendance);
				RequestDispatcher list = request.getRequestDispatcher("attendanceview.jsp");
				request.setAttribute("attendances", dao.getAllAttendance());
				list.forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("status", "error");
		}
		request.getRequestDispatcher("/attendance.jsp").forward(request, response);

	}

}
