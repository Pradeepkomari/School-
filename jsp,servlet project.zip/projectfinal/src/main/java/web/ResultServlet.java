package web;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Result;
import java.io.IOException;
import java.sql.SQLException;
import dao.ResultDao;

@WebServlet("/result")
public class ResultServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	ResultDao dao;

	public ResultServlet() throws ClassNotFoundException, SQLException {

		super();
		dao = new ResultDao();

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());

		String action = request.getParameter("action");

		if (action == null) {
			action = "default";
		}
		switch (action) {

		case "delete":

			int id = Integer.parseInt(request.getParameter("id"));
			dao.delete(id);
			RequestDispatcher del = request.getRequestDispatcher("resultview.jsp");
			request.setAttribute("results", dao.getAllResult());
			del.forward(request, response);

			break;

		case "edit":

			RequestDispatcher edit = request.getRequestDispatcher("result.jsp");
			id = Integer.parseInt(request.getParameter("id"));
			Result result = dao.editResult(id);
			request.setAttribute("result", result);
			edit.forward(request, response);
			break;

		default:

			RequestDispatcher view = request.getRequestDispatcher("resultview.jsp");
			request.setAttribute("results", dao.getAllResult());
			view.forward(request, response);
			break;
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// doGet(request, response);

		Result result = new Result();

		result.setRollnum(request.getParameter("rollnum"));
		result.setName(request.getParameter("name"));
		result.setStd(request.getParameter("grade"));
		result.setSec(request.getParameter("section"));
		result.setEnglish(request.getParameter("englishmarks"));
		result.setLanguage(request.getParameter("languagemarks"));
		result.setMaths(request.getParameter("mathsmarks"));
		result.setSocial(request.getParameter("socialmarks"));
		result.setScience(request.getParameter("sciencemarks"));
		result.setComputer(request.getParameter("computermarks"));

		double englishmarks = parseDouble(request.getParameter("englishmarks"));
		double languagemarks = parseDouble(request.getParameter("languagemarks"));
		double mathsmarks = parseDouble(request.getParameter("mathsmarks"));
		double socialmarks = parseDouble(request.getParameter("socialmarks"));
		double sciencemarks = parseDouble(request.getParameter("sciencemarks"));
		double computermarks = parseDouble(request.getParameter("computermarks"));

		double totalmarks = englishmarks + languagemarks + mathsmarks + socialmarks + sciencemarks + computermarks;

		result.setTotal(totalmarks);

		String id = request.getParameter("id");
		try {
			if (id == null || id.isEmpty()) {
				dao.addDetails(result);
				request.setAttribute("status", "success");
			} else {
				result.setId(Integer.parseInt(id));
				dao.updateresult(result);
				RequestDispatcher list = request.getRequestDispatcher("resultview.jsp");
				request.setAttribute("results", dao.getAllResult());
				list.forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("status", "error");
		}
		request.getRequestDispatcher("/result.jsp").forward(request, response);

	}

	private double parseDouble(String str) {
		if (str == null || str.isEmpty()) {
			return 0.0; // Default to 0 if the parameter is null or empty
		}
		return Double.parseDouble(str);
	}

}
