package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import db.DbConnect;
import model.PersonalBean;

public class PersonalDao {

	Connection con;

	public PersonalDao() throws ClassNotFoundException, SQLException {
		con = DbConnect.getconnection();
	}

	public void addDetails(PersonalBean beans) {

		try {
			PreparedStatement pst = con.prepareStatement("insert into personal (rollnum ,name,dob,gender,class,"
					+ "section,fatherName,motherName,nationality,mothertongue,address,contact,email)"
					+ " values(?,?,?,?,?,?,?,?,?,?,?,?,?)");

			pst.setString(1, beans.getRollnum());
			pst.setString(2, beans.getName());
			pst.setString(3, beans.getDob());
			pst.setString(4, beans.getGender());
			pst.setString(5, beans.getStd());
			pst.setString(6, beans.getSec());
			pst.setString(7, beans.getFather());
			pst.setString(8, beans.getMother());
			pst.setString(9, beans.getNationality());
			pst.setString(10, beans.getMothertongue());
			pst.setString(11, beans.getAddress());
			pst.setString(12, beans.getContact());
			pst.setString(13, beans.getEmail());

			pst.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public List<PersonalBean> getAllPersonal() {

		List<PersonalBean> personal = new ArrayList<PersonalBean>();
		try {
			java.sql.Statement sta = con.createStatement();

			ResultSet rs = sta.executeQuery("select * from personal");

			while (rs.next()) {

				PersonalBean bean = new PersonalBean();

				bean.setId(rs.getInt("id"));
				bean.setRollnum(rs.getNString("rollnum"));
				bean.setName(rs.getString("name"));
				bean.setDob(rs.getString("dob"));
				bean.setGender(rs.getString("gender"));
				bean.setStd(rs.getString("class"));
				bean.setSec(rs.getString("section"));
				bean.setFather(rs.getString("fatherName"));
				bean.setMother(rs.getString("motherName"));
				bean.setNationality(rs.getString("nationality"));
				bean.setMothertongue(rs.getString("mothertongue"));
				bean.setAddress(rs.getString("address"));
				bean.setContact(rs.getString("contact"));
				bean.setEmail(rs.getString("email"));

				personal.add(bean);
			}

		} catch (SQLException e) {
			// TODO: handle exception
		}
		return personal;

	}

	public void deleteDetails(int id) {

		try {
			PreparedStatement pst = con.prepareStatement("Delete from personal where id =?");
			pst.setInt(1, id);
			pst.executeUpdate();
		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

	public PersonalBean editDetails(int id) {

		PersonalBean bean = new PersonalBean();

		try {

			PreparedStatement pst = con.prepareStatement("select * from  personal where id=?");
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();

			while (rs.next()) {

				bean.setRollnum(rs.getNString("rollnum"));
				bean.setName(rs.getString("name"));
				bean.setDob(rs.getString("dob"));
				bean.setGender(rs.getString("gender"));
				bean.setStd(rs.getString("class"));
				bean.setSec(rs.getString("section"));
				bean.setFather(rs.getString("fatherName"));
				bean.setMother(rs.getString("motherName"));
				bean.setNationality(rs.getString("nationality"));
				bean.setMothertongue(rs.getString("mothertongue"));
				bean.setAddress(rs.getString("address"));
				bean.setContact(rs.getString("contact"));
				bean.setEmail(rs.getString("email"));

			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return bean;

	}

	public void updatepersonal(PersonalBean beans) {
	    try {
	        PreparedStatement pst = con.prepareStatement("update personal set "
	                + "rollnum=?, name=?, dob=?, gender=?, class=?, section=?, "
	                + "fatherName=?, motherName=?, nationality=?, mothertongue=?, address=?, "
	                + "contact=?, email=? "
	                + "where id=?");

	        pst.setString(1, beans.getRollnum());
	        pst.setString(2, beans.getName());
	        pst.setString(3, beans.getDob());
	        pst.setString(4, beans.getGender());
	        pst.setString(5, beans.getStd());
	        pst.setString(6, beans.getSec());
	        pst.setString(7, beans.getFather());
	        pst.setString(8, beans.getMother());
	        pst.setString(9, beans.getNationality());
	        pst.setString(10, beans.getMothertongue());
	        pst.setString(11, beans.getAddress());
	        pst.setString(12, beans.getContact());
	        pst.setString(13, beans.getEmail());
	        
	        pst.setInt(14, beans.getId());

	        pst.executeUpdate();

	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

}
