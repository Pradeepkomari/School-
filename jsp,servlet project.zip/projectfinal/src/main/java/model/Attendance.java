package model;

public class Attendance {
	private int id;
	private String rollnum;
	private String name;
	private String std;
	private String sec;
	private String totaldays;
	private String leavedays;
	private double percentage;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getRollnum() {
		return rollnum;
	}
	public void setRollnum(String rollnum) {
		this.rollnum = rollnum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStd() {
		return std;
	}
	public void setStd(String std) {
		this.std = std;
	}
	public String getSec() {
		return sec;
	}
	public void setSec(String sec) {
		this.sec = sec;
	}
	public String getTotaldays() {
		return totaldays;
	}
	public void setTotaldays(String totaldays) {
		this.totaldays = totaldays;
	}
	public String getLeavedays() {
		return leavedays;
	}
	public void setLeavedays(String leavedays) {
		this.leavedays = leavedays;
	}
	public double getPercentage() {
		return percentage;
	}
	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}
	
	@Override
	public String toString() {
		return "Attendance [id=" + id + ", rollnum=" + rollnum + ", name=" + name + ", std=" + std + ", sec=" + sec
				+ ", totaldays=" + totaldays + ", leavedays=" + leavedays + ", percentage=" + percentage + "]";
	}

}
