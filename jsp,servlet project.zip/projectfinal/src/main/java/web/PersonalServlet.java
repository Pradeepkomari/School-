package web;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.PersonalBean;
import java.io.IOException;
import java.sql.SQLException;
import dao.PersonalDao;

@WebServlet("/personal")
public class PersonalServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */

	private PersonalDao dao;

	public PersonalServlet() throws ClassNotFoundException, SQLException {
		super();

		dao = new PersonalDao();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());

		String action = request.getParameter("action");

		if (action == null) {
			action = "default";
		}

		switch (action) {
		case "delete":

			// System.out.println(action);

			int id = Integer.parseInt(request.getParameter("id"));
			dao.deleteDetails(id);
			RequestDispatcher del = request.getRequestDispatcher("personalview.jsp");
			request.setAttribute("personals", dao.getAllPersonal());
			del.forward(request, response);

			break;

		case "edit":

			// System.out.println(action);
			RequestDispatcher edit = request.getRequestDispatcher("personal.jsp");
			id = Integer.parseInt(request.getParameter("id"));
			PersonalBean personal = dao.editDetails(id);
			request.setAttribute("personal", personal);
			edit.forward(request, response);

			break;

		default:

			RequestDispatcher view = request.getRequestDispatcher("personalview.jsp");
			request.setAttribute("personals", dao.getAllPersonal());
			view.forward(request, response);
			break;

		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PersonalBean personal = new PersonalBean();

		personal.setRollnum(request.getParameter("rollnum"));
		personal.setName(request.getParameter("sname"));
		personal.setDob(request.getParameter("dob"));
		personal.setGender(request.getParameter("gender"));
		personal.setStd(request.getParameter("grade"));
		personal.setSec(request.getParameter("section"));
		personal.setFather(request.getParameter("fathername"));
		personal.setMother(request.getParameter("mothername"));
		personal.setNationality(request.getParameter("nationality"));
		personal.setMothertongue(request.getParameter("mothertongue"));
		personal.setAddress(request.getParameter("address"));
		personal.setContact(request.getParameter("contact"));
		personal.setEmail(request.getParameter("email"));
		
		String id = request.getParameter("id");
		try {
			if (id == null || id.isEmpty()) {
				dao.addDetails(personal);
				request.setAttribute("status", "success");
			} else {
				personal.setId(Integer.parseInt(id));
				dao.updatepersonal(personal);
				RequestDispatcher list = request.getRequestDispatcher("personalview.jsp");
				request.setAttribute("personals", dao.getAllPersonal());
				list.forward(request, response);

			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("status", "error");
		}
		request.getRequestDispatcher("/personal.jsp").forward(request, response);

	}

}
