package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import db.DbConnect;
import model.Fees;

public class FeesDao {
	
	Connection con;
	
	public FeesDao()throws ClassNotFoundException, SQLException {
		
		con = DbConnect.getconnection();
		
	}
	
	public void addDetails(Fees beans) {

		try {
			PreparedStatement pst = con.prepareStatement("insert into fees (rollnum ,name,class,"
					+ "section,tutionsfees,vanfees,bookfees,examfees,labfees,otherfees,email,total)"
					+ " values(?,?,?,?,?,?,?,?,?,?,?,?)");

			pst.setString(1, beans.getRollnum());
			pst.setString(2, beans.getName());
			pst.setString(3, beans.getStd());
			pst.setString(4, beans.getSec());
			pst.setString(5, beans.getTutionsfees());
			pst.setString(6, beans.getVanfees());
			pst.setString(7, beans.getBookfees());
			pst.setString(8, beans.getExamfees());
			pst.setString(9, beans.getLabfees());
			pst.setString(10, beans.getOtherfees());
			pst.setString(11, beans.getEmail());
			pst.setDouble(12, beans.getTotalfees());
			

			pst.executeUpdate();

		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
	
	public List<Fees> getAllFees() {

		List<Fees> fees = new ArrayList<Fees>();
		try {
			java.sql.Statement sta = con.createStatement();

			ResultSet rs = sta.executeQuery("select * from fees");

			while (rs.next()) {

				Fees bean = new Fees();

				bean.setId(rs.getInt("id"));
				bean.setRollnum(rs.getNString("rollnum"));
				bean.setName(rs.getString("name"));
				bean.setStd(rs.getString("class"));
				bean.setSec(rs.getString("section"));
				bean.setTutionsfees(rs.getString("tutionsfees"));
				bean.setVanfees(rs.getString("vanfees"));
				bean.setBookfees(rs.getString("bookfees"));
				bean.setExamfees(rs.getString("examfees"));
				bean.setLabfees(rs.getString("labfees"));
				bean.setOtherfees(rs.getString("otherfees"));
				bean.setEmail(rs.getString("email"));
				bean.setTotalfees(rs.getDouble("total"));

				fees.add(bean);
			}

		} catch (SQLException e) {
			// TODO: handle exception
		}
		return fees;

	}
	
	public void deleteFees(int id) {

		try {
			PreparedStatement pst = con.prepareStatement("Delete from fees where id =?");
			pst.setInt(1, id);
			pst.executeUpdate();
		} catch (SQLException e) {

			e.printStackTrace();
		}

	}
	
	public Fees editFees(int id) {

		Fees bean = new Fees();

		try {

			PreparedStatement pst = con.prepareStatement("select * from  fees where id=?");
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();

			while (rs.next()) {

				bean.setId(rs.getInt("id"));
				bean.setRollnum(rs.getNString("rollnum"));
				bean.setName(rs.getString("name"));
				bean.setStd(rs.getString("class"));
				bean.setSec(rs.getString("section"));
				bean.setTutionsfees(rs.getString("tutionsfees"));
				bean.setVanfees(rs.getString("vanfees"));
				bean.setBookfees(rs.getString("bookfees"));
				bean.setExamfees(rs.getString("examfees"));
				bean.setLabfees(rs.getString("labfees"));
				bean.setOtherfees(rs.getString("otherfees"));
				bean.setEmail(rs.getString("email"));
				bean.setTotalfees(rs.getDouble("total"));

			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return bean;

	}
	
	public void updatefees(Fees beans) {

		try {
			PreparedStatement pst = con.prepareStatement("update fees set rollnum=?, name=?, class=?, section=?, tutionsfees=?, vanfees=?, bookfees=?, examfees=?, labfees=?, otherfees=?, email=? ,total=? "
					+ "where id=?;");
			
			

			pst.setString(1, beans.getRollnum());
			pst.setString(2, beans.getName());
			pst.setString(3, beans.getStd());
			pst.setString(4, beans.getSec());
			pst.setString(5, beans.getTutionsfees());
			pst.setString(6, beans.getVanfees());
			pst.setString(7, beans.getBookfees());
			pst.setString(8, beans.getExamfees());
			pst.setString(9, beans.getLabfees());
			pst.setString(10, beans.getOtherfees());
			pst.setString(11, beans.getEmail());
			pst.setDouble(12, beans.getTotalfees());
			
			pst.setInt(13, beans.getId());

			pst.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	

}
