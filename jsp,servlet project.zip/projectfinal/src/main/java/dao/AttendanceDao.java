package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import db.DbConnect;
import model.Attendance;


public class AttendanceDao {

	Connection con;

	public AttendanceDao() throws ClassNotFoundException, SQLException {
		con = DbConnect.getconnection();
	}

	public void addDetails(Attendance beans) {

		try {
			PreparedStatement pst = con.prepareStatement("insert into attendance (rollnum ,name,class,"
					+ "section,totaldays,leavedays,percentage)" + " values(?,?,?,?,?,?,?)");

			pst.setString(1, beans.getRollnum());
			pst.setString(2, beans.getName());
			pst.setString(3, beans.getStd());
			pst.setString(4, beans.getSec());
			pst.setString(5, beans.getTotaldays());
			pst.setString(6, beans.getLeavedays());
			pst.setDouble(7, beans.getPercentage());

			pst.executeUpdate();

		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

	public List<Attendance> getAllAttendance() {

		List<Attendance> attendances = new ArrayList<Attendance>();

		try {

			java.sql.Statement sta = con.createStatement();

			ResultSet rs = sta.executeQuery("select * from attendance");

			while (rs.next()) {

				Attendance bean = new Attendance();

				bean.setId(rs.getInt("id"));
				bean.setRollnum(rs.getNString("rollnum"));
				bean.setName(rs.getString("name"));
				bean.setStd(rs.getString("class"));
				bean.setSec(rs.getString("section"));
				bean.setTotaldays(rs.getString("totaldays"));
				bean.setLeavedays(rs.getString("leavedays"));
				bean.setPercentage(rs.getDouble("percentage"));

				attendances.add(bean);
			}

		} catch (SQLException e) {

			e.printStackTrace();

		}

		return attendances;

	}

	public void delete(int id) {

		try {
			PreparedStatement pst = con.prepareStatement("Delete from attendance where id =?");
			pst.setInt(1, id);
			pst.executeUpdate();
		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

	public Attendance editAttendance(int id) {

		Attendance bean = new Attendance();

		try {

			PreparedStatement pst = con.prepareStatement("select * from  attendance where id=?");
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();

			while (rs.next()) {

				bean.setId(rs.getInt("id"));
				bean.setRollnum(rs.getNString("rollnum"));
				bean.setName(rs.getString("name"));
				bean.setStd(rs.getString("class"));
				bean.setSec(rs.getString("section"));
				bean.setTotaldays(rs.getString("totaldays"));
				bean.setLeavedays(rs.getString("leavedays"));
				bean.setPercentage(rs.getDouble("percentage"));

			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return bean;

	}
	
	public void updateattendance(Attendance beans) {
	
		try {
			PreparedStatement pst = con.prepareStatement("update attendance set rollnum=?, name=?, class=?, "
					+ "section=?, totaldays=?, leavedays=?, percentage=?"
					+ " where id=?");
			 
			pst.setString(1, beans.getRollnum());
			pst.setString(2, beans.getName());
			pst.setString(3, beans.getStd());
			pst.setString(4, beans.getSec());
			pst.setString(5, beans.getTotaldays());
			pst.setString(6, beans.getLeavedays());
			pst.setDouble(7, beans.getPercentage());
			pst.setInt(8, beans.getId());

			pst.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	
	

}
