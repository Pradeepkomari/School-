package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import db.DbConnect;
import model.Transport;

public class TransportDao {

	Connection con;

	public TransportDao() throws ClassNotFoundException, SQLException {

		con = DbConnect.getconnection();

	}

	public void addDetails(Transport beans) {

		try {
			PreparedStatement pst = con.prepareStatement("insert into transport (rollnum ,name,class,"
					+ "section,gender,address,route,vannum,contact)" + " values(?,?,?,?,?,?,?,?,?)");

			pst.setString(1, beans.getRollnum());
			pst.setString(2, beans.getName());
			pst.setString(3, beans.getStd());
			pst.setString(4, beans.getSec());
			pst.setString(5, beans.getGender());
			pst.setString(6, beans.getAddress());
			pst.setString(7, beans.getRoute());
			pst.setInt(8, beans.getVannum());
			pst.setString(9, beans.getContact());

			pst.executeUpdate();

		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

	public List<Transport> getAllTransport() {

		List<Transport> transports = new ArrayList<Transport>();

		try {

			java.sql.Statement sta = con.createStatement();

			ResultSet rs = sta.executeQuery("select * from transport");

			while (rs.next()) {

				Transport bean = new Transport();

				bean.setId(rs.getInt("id"));
				bean.setRollnum(rs.getNString("rollnum"));
				bean.setName(rs.getString("name"));
				bean.setStd(rs.getString("class"));
				bean.setSec(rs.getString("section"));
				bean.setGender(rs.getString("gender"));
				bean.setAddress(rs.getString("address"));
				bean.setRoute(rs.getString("route"));
				bean.setVannum(rs.getInt("vannum"));
				bean.setContact(rs.getString("contact"));

				transports.add(bean);
			}

		} catch (SQLException e) {
			// TODO: handle exception
		}

		return transports;

	}

	public void delete(int id) {

		try {
			PreparedStatement pst = con.prepareStatement("Delete from transport where id =?");
			pst.setInt(1, id);
			pst.executeUpdate();
		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

	public Transport editTransport(int id) {

		Transport bean = new Transport();

		try {

			PreparedStatement pst = con.prepareStatement("select * from  transport where id=?");
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();

			while (rs.next()) {

				bean.setId(rs.getInt("id"));
				bean.setRollnum(rs.getNString("rollnum"));
				bean.setName(rs.getString("name"));
				bean.setStd(rs.getString("class"));
				bean.setSec(rs.getString("section"));
				bean.setGender(rs.getString("gender"));
				bean.setAddress(rs.getString("address"));
				bean.setRoute(rs.getString("route"));
				bean.setVannum(rs.getInt("vannum"));
				bean.setContact(rs.getString("contact"));

			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return bean;

	}
	
	public void updatetransport(Transport beans) {
		
		
		try {
			
			PreparedStatement pst = con.prepareStatement("update attendance set rollnum=?, name=?, class=?, "
					+ "section=?, gender=?, address=?, route=?, vannum=?, contact=?"
					+ " where id=?");
			
			
			pst.setString(1, beans.getRollnum());
			pst.setString(2, beans.getName());
			pst.setString(3, beans.getStd());
			pst.setString(4, beans.getSec());
			pst.setString(5, beans.getGender());
			pst.setString(6, beans.getAddress());
			pst.setString(7, beans.getRoute());
			pst.setInt(8, beans.getVannum());
			pst.setString(9, beans.getContact());
			
			pst.setInt(10, beans.getId());

			pst.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	

}
