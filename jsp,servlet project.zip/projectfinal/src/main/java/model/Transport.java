package model;

public class Transport {
	
	private int id;
	private String rollnum;
	private String name;
	private String std;
	private String sec;
	private String gender;
	private String address;
	private String route;
	private int vannum;
	private String contact;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getRollnum() {
		return rollnum;
	}
	public void setRollnum(String rollnum) {
		this.rollnum = rollnum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStd() {
		return std;
	}
	public void setStd(String std) {
		this.std = std;
	}
	public String getSec() {
		return sec;
	}
	public void setSec(String sec) {
		this.sec = sec;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getRoute() {
		return route;
	}
	public void setRoute(String route) {
		this.route = route;
	}
	public int getVannum() {
		return vannum;
	}
	public void setVannum(int vannum) {
		this.vannum = vannum;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	@Override
	public String toString() {
		return "Transport [id=" + id + ", rollnum=" + rollnum + ", name=" + name + ", std=" + std + ", sec=" + sec
				+ ", gender=" + gender + ", address=" + address + ", route=" + route + ", vannum=" + vannum
				+ ", contact=" + contact + "]";
	}
	
	
	

}
