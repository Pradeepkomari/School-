package web;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Fees;
import java.io.IOException;
import java.sql.SQLException;

import dao.FeesDao;

@WebServlet("/fee")
public class FeesServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	private FeesDao dao;

	public FeesServlet() throws ClassNotFoundException, SQLException {
		super();
		dao = new FeesDao();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		response.getWriter().append("Served at: ").append(request.getContextPath());

		String action = request.getParameter("action");

		if (action == null) {
			action = "default";
		}

		switch (action) {
		case "delete":

			int id = Integer.parseInt(request.getParameter("id"));
			dao.deleteFees(id);
			RequestDispatcher del = request.getRequestDispatcher("feesview.jsp");
			request.setAttribute("fees", dao.getAllFees());
			del.forward(request, response);

			break;

		case "edit":

			RequestDispatcher edit = request.getRequestDispatcher("fees.jsp");
			id = Integer.parseInt(request.getParameter("id"));
			Fees fees = dao.editFees(id);
			request.setAttribute("fee", fees);
			edit.forward(request, response);

			break;

		default:

			RequestDispatcher view = request.getRequestDispatcher("feesview.jsp");
			request.setAttribute("fees", dao.getAllFees());
			view.forward(request, response);
			break;

		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);
		Fees beans = new Fees();

		beans.setRollnum(request.getParameter("rollNum"));
		beans.setName(request.getParameter("sname"));
		beans.setStd(request.getParameter("grade"));
		beans.setSec(request.getParameter("section"));
		beans.setTutionsfees(request.getParameter("tuitionFees"));
		beans.setVanfees(request.getParameter("vanFees"));
		beans.setBookfees(request.getParameter("bookFees"));
		beans.setExamfees(request.getParameter("examFees"));
		beans.setLabfees(request.getParameter("labFees"));
		beans.setOtherfees(request.getParameter("otherFees"));
		beans.setEmail(request.getParameter("email"));

		double tuitionFees = parseDouble(request.getParameter("tuitionFees"));
		double vanFees = parseDouble(request.getParameter("vanFees"));
		double bookFees = parseDouble(request.getParameter("bookFees"));
		double examFees = parseDouble(request.getParameter("examFees"));
		double labFees = parseDouble(request.getParameter("labFees"));
		double otherFees = parseDouble(request.getParameter("otherFees"));

		double totalFees = tuitionFees + vanFees + bookFees + examFees + labFees + otherFees;

		beans.setTotalfees(totalFees);

		String id = request.getParameter("id");
		try {
			if (id == null || id.isEmpty()) {
				dao.addDetails(beans);
				request.setAttribute("status", "success");
			} else {
				beans.setId(Integer.parseInt(id));
				dao.updatefees(beans);
				RequestDispatcher list = request.getRequestDispatcher("feesview.jsp");
				request.setAttribute("fees", dao.getAllFees());
				list.forward(request, response);
				
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("status", "error");
		}
		request.getRequestDispatcher("/fees.jsp").forward(request, response);

	}

	private double parseDouble(String str) {
		if (str == null || str.isEmpty()) {
			return 0.0; // Default to 0 if the parameter is null or empty
		}
		return Double.parseDouble(str);
	}

}
