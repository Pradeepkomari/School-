package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import db.DbConnect;
import model.Result;

public class ResultDao {

	Connection con;

	public ResultDao() throws ClassNotFoundException, SQLException {

		con = DbConnect.getconnection();
	}

	public void addDetails(Result beans) {

		try {
			PreparedStatement pst = con.prepareStatement("insert into result (rollnum ,name,class,"
					+ "section,english,language,maths,social,science,computer,total)"
					+ " values(?,?,?,?,?,?,?,?,?,?,?)");

			pst.setString(1, beans.getRollnum());
			pst.setString(2, beans.getName());
			pst.setString(3, beans.getStd());
			pst.setString(4, beans.getSec());
			pst.setString(5, beans.getEnglish());
			pst.setString(6, beans.getLanguage());
			pst.setString(7, beans.getMaths());
			pst.setString(8, beans.getSocial());
			pst.setString(9, beans.getScience());
			pst.setString(10, beans.getComputer());
			pst.setDouble(11, beans.getTotal());

			pst.executeUpdate();

		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

	public List<Result> getAllResult() {

		List<Result> results = new ArrayList<Result>();

		try {

			java.sql.Statement sta = con.createStatement();

			ResultSet rs = sta.executeQuery("select * from result");

			while (rs.next()) {

				Result bean = new Result();

				bean.setId(rs.getInt("id"));
				bean.setRollnum(rs.getNString("rollnum"));
				bean.setName(rs.getString("name"));
				bean.setStd(rs.getString("class"));
				bean.setSec(rs.getString("section"));
				bean.setEnglish(rs.getString("english"));
				bean.setLanguage(rs.getString("language"));
				bean.setMaths(rs.getString("maths"));
				bean.setSocial(rs.getString("social"));
				bean.setScience(rs.getString("science"));
				bean.setComputer(rs.getString("computer"));
				bean.setTotal(rs.getDouble("total"));

				results.add(bean);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return results;

	}

	public void delete(int id) {

		try {
			PreparedStatement pst = con.prepareStatement("Delete from result where id =?");
			pst.setInt(1, id);
			pst.executeUpdate();
		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

	public Result editResult(int id) {

		Result result = new Result();

		try {

			PreparedStatement pst = con.prepareStatement("select * from  result where id=?");
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();

			while (rs.next()) {

				result.setId(rs.getInt("id"));
				result.setRollnum(rs.getNString("rollnum"));
				result.setName(rs.getString("name"));
				result.setStd(rs.getString("class"));
				result.setSec(rs.getString("section"));
				result.setEnglish(rs.getString("english"));
				result.setLanguage(rs.getString("language"));
				result.setMaths(rs.getString("maths"));
				result.setSocial(rs.getString("social"));
				result.setScience(rs.getString("science"));
				result.setComputer(rs.getString("computer"));
				result.setTotal(rs.getDouble("total"));

			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return result;

	}
	
	public void updateresult(Result beans) {
		
		try {
			PreparedStatement pst = con.prepareStatement("update result set rollnum=?, name=?, class=?, section=?, "
					+ "english=?, language=?, maths=?, social=?, science=?, computer=?, total=? "
					+ " where id=?");
			 
			pst.setString(1, beans.getRollnum());
			pst.setString(2, beans.getName());
			pst.setString(3, beans.getStd());
			pst.setString(4, beans.getSec());
			pst.setString(5, beans.getEnglish());
			pst.setString(6, beans.getLanguage());
			pst.setString(7, beans.getMaths());
			pst.setString(8, beans.getSocial());
			pst.setString(9, beans.getScience());
			pst.setString(10, beans.getComputer());
			pst.setDouble(11, beans.getTotal());

			pst.setInt(12, beans.getId());

			pst.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	

}
