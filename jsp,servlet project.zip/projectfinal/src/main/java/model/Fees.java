package model;

public class Fees {

	private int id;
	private String rollnum;
	private String name;
	private String std;
	private String sec;
	private String tutionsfees;
	private String vanfees;
	private String bookfees;
	private String examfees;
	private String labfees;
	private String otherfees;
	private String email;
	private double totalfees;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getRollnum() {
		return rollnum;
	}

	public void setRollnum(String rollnum) {
		this.rollnum = rollnum;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStd() {
		return std;
	}

	public void setStd(String std) {
		this.std = std;
	}

	public String getSec() {
		return sec;
	}

	public void setSec(String sec) {
		this.sec = sec;
	}

	public String getTutionsfees() {
		return tutionsfees;
	}

	public void setTutionsfees(String tutionsfees) {
		this.tutionsfees = tutionsfees;
	}

	public String getVanfees() {
		return vanfees;
	}

	public void setVanfees(String vanfees) {
		this.vanfees = vanfees;
	}

	public String getBookfees() {
		return bookfees;
	}

	public void setBookfees(String bookfees) {
		this.bookfees = bookfees;
	}

	public String getExamfees() {
		return examfees;
	}

	public void setExamfees(String examfees) {
		this.examfees = examfees;
	}

	public String getLabfees() {
		return labfees;
	}

	public void setLabfees(String labfees) {
		this.labfees = labfees;
	}

	public String getOtherfees() {
		return otherfees;
	}

	public void setOtherfees(String otherfees) {
		this.otherfees = otherfees;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public double getTotalfees() {
		return totalfees;
	}

	public void setTotalfees(double totalFees) {
		this.totalfees = totalFees;
	}

}
