package web;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Transport;
import java.io.IOException;
import java.sql.SQLException;
import dao.TransportDao;

/**
 * Servlet implementation class TransportServlet
 */

@WebServlet("/transport")
public class TransportServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	TransportDao dao;

	public TransportServlet() throws ClassNotFoundException, SQLException {
		super();

		dao = new TransportDao();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		response.getWriter().append("Served at: ").append(request.getContextPath());

		String action = request.getParameter("action");

		if (action == null) {
			action = "default";
		}
		switch (action) {

		case "delete":

			int id = Integer.parseInt(request.getParameter("id"));
			dao.delete(id);
			RequestDispatcher del = request.getRequestDispatcher("transportview.jsp");
			request.setAttribute("transports", dao.getAllTransport());
			del.forward(request, response);

			break;

		case "edit":

			RequestDispatcher edit = request.getRequestDispatcher("transport.jsp");
			id = Integer.parseInt(request.getParameter("id"));
			Transport transport = dao.editTransport(id);
			request.setAttribute("transport", transport);
			edit.forward(request, response);
			break;
			
			
		default:

			RequestDispatcher view = request.getRequestDispatcher("transportview.jsp");
			request.setAttribute("transports", dao.getAllTransport());
			view.forward(request, response);
			break;
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// doGet(request, response);

		Transport transport = new Transport();

		transport.setRollnum(request.getParameter("rollnum"));
		transport.setName(request.getParameter("name"));
		transport.setStd(request.getParameter("grade"));
		transport.setSec(request.getParameter("section"));
		transport.setGender(request.getParameter("gender"));
		transport.setAddress(request.getParameter("address"));
		transport.setRoute(request.getParameter("route"));
		transport.setVannum(Integer.parseInt(request.getParameter("van")));
		transport.setContact(request.getParameter("contact"));

		String id = request.getParameter("id");
		try {
			if (id == null || id.isEmpty()) {
				dao.addDetails(transport);
				request.setAttribute("status", "success");
			} else {
				transport.setId(Integer.parseInt(id));
			    dao.updatetransport(transport);
			    request.setAttribute("transports", dao.getAllTransport());
			    RequestDispatcher list = request.getRequestDispatcher("transportview.jsp");
				list.forward(request, response);

			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("status", "error");
		}
		request.getRequestDispatcher("/transport.jsp").forward(request, response);

	}

}
